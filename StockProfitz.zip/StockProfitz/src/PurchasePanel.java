import java.awt.*;
import javax.swing.event.*;
import javax.swing.*;


public class PurchasePanel extends JPanel {
    private JLabel purchaseLabel;
    private JTextField purchaseField;

    public PurchasePanel() {

        setLayout(new GridLayout(2, 1));


        setBorder(BorderFactory.createTitledBorder("Step 3"));

        purchaseLabel = new JLabel("Purchase Price");   
        purchaseField = new JTextField(10);

        add(purchaseLabel);
        add(purchaseField);
    }
}

