import java.awt.*;
import javax.swing.event.*;
import javax.naming.directory.SearchResult;
import javax.swing.*;
import javax.swing.border.Border;

public class StockPanel extends JPanel {
    private JTextField stockField;
    private JLabel stockName;

    public StockPanel() {

        setLayout(new GridLayout(2, 1));

        setBorder(BorderFactory.createTitledBorder("Step 1"));

        stockName = new JLabel("Stock name");   
        stockField = new JTextField(10);

        add(stockName);
        add(stockField);
    }
}