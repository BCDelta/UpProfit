import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
public class SharePanel extends JPanel {

    private JLabel shares;
    private JTextField shareField;

    public SharePanel() {
        
        setLayout(new GridLayout(2, 1));


        setBorder(BorderFactory.createTitledBorder("Step 2"));

        shares = new JLabel("Number of Shares");   
        shareField= new JTextField(10);

        add(shares);
        add(shareField);
    }
    
}
