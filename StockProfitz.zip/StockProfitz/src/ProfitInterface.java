public interface ProfitInterface {
    String getAmount();
}
