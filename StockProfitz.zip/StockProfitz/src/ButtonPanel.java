import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class ButtonPanel extends JPanel {
    public ButtonPanel() {

    }
}
