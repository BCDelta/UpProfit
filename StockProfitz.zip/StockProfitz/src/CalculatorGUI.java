import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class CalculatorGUI extends JFrame {

    private StockBlock stockPanel;
    private TitlePanel title;
    private JPanel buttonPanel;
    private JButton calculate, reset;

    public CalculatorGUI() {
        setTitle("Up-Profit");

        setLayout(new BorderLayout());

        title = new TitlePanel();
        stockPanel = new StockBlock();

        buildButtonPanel();
        
        add(title, BorderLayout.NORTH, SwingConstants.CENTER);
        add(stockPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        pack();
        setVisible(true);
    }

    private void buildButtonPanel() {

        buttonPanel = new JPanel();

        buttonPanel.setBorder(BorderFactory.createTitledBorder("Step 5"));

        calculate = new JButton("Calculate");
        reset = new JButton("Reset");

        buttonPanel.add(calculate);
        buttonPanel.add(reset);
    }
}
