import java.awt.*;
import javax.swing.event.*;
import javax.swing.*;


public class StockBlock extends JPanel {
    
// -----------------------------------------------------------------------------------------------------//
    private StockPanel stockPanel;
    private SharePanel sharesPanel;
    private SellPanel sellPanel;
    private PurchasePanel purchasePanel;
// -----------------------------------------------------------------------------------------------------//

    /**
     * Constructor for class
     */
    public StockBlock() {

        setLayout(new GridLayout(1,4));

        stockPanel = new StockPanel();
        sharesPanel = new SharePanel();
        purchasePanel = new PurchasePanel();
        sellPanel = new SellPanel();

        add(stockPanel);
        add(sharesPanel);
        add(purchasePanel);
        add(sellPanel);
        
    }

}
