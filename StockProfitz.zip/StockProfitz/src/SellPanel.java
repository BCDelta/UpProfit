import java.awt.*;
import javax.swing.event.*;
import javax.swing.*;

public class SellPanel extends JPanel {
    private JLabel sellLabel;
    private JTextField sellPrice;

    public SellPanel() {

        setLayout(new GridLayout(2, 1));


        setBorder(BorderFactory.createTitledBorder("Step 4"));

        sellLabel = new JLabel("Sell Price");   
        sellPrice = new JTextField(10);

        add(sellLabel);
        add(sellPrice);
    }
}
